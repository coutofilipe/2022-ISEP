/*
 * Instituto Superior de Engenharia do Porto
 * Licenciatura em Engenharia Informática
 */
package exames2016;

import exames2016.DoublyLinkedList;
import java.util.Iterator;

/**
 *
 * @author Tiago Ferreira <1150556@isep.ipp.pt>
 */
public class Exames2016 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        DoublyLinkedList<Integer> serie = new DoublyLinkedList<>();
        serie.addLast(2);
        serie.addLast(4);
        serie.addLast(3);
        serie.addLast(7);
        serie.addLast(8);
        serie.addLast(10);
        
        Iterator<Integer> it = calcMMS(serie,3).iterator();
        
        while(it.hasNext()){
            System.out.println(it.next());
        }
    }
    
    private static DoublyLinkedList<Integer> calcMMS(DoublyLinkedList<Integer> serie, Integer period){
        if(serie.isEmpty()) return null;
        
        int soma = 0, pivot = 0;
        DoublyLinkedList<Integer> res = new DoublyLinkedList<>();
        
        for(int i = 1; i <= serie.size(); i++){
            int temp = serie.first();
            soma += temp;
            
            if(i >= period){
                res.addLast(soma/temp);
                soma -= pivot;
            }else{
                res.addLast(0);
            }
            serie.removeFirst();
            pivot = temp;
        }
        
        return res;
    }
    
}
