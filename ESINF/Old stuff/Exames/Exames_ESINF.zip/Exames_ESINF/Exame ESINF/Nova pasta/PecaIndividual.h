#ifndef PECAINDIVIDUAL_H
#define PECAINDIVIDUAL_H

#include "Peca.h"

class PecaIndividual:public Peca{ //definir a classe peca como classe m�e desta
private:
	string tipoEmbalagem;
public:
	PecaIndividual(void);
	PecaIndividual(int, string); //O inteiro � para chamar o construtor da classe m�e que recebe o c�digo da pe�a, definido com int
	PecaIndividual(const PecaIndividual&);
	~PecaIndividual(void);

	void setTipoEmbalagem(string);
	string getTipoEmbalagem(void) const;

	PecaIndividual* clone(void) const; //clone
	
	const PecaIndividual& operator=(const PecaIndividual&);
	bool operator==(const PecaIndividual&) const;

	void listar(ostream&) const;
}

	ostream& operator<<(ostream&, const PecaIndividual&);

#endif