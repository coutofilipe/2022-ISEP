#ifndef MULTISTACK_H
#define MULTISTACK_H

#include <iostream>
#include <stack> //N�o sei se no exame deixam utilizar STL, este ex est� resolvido usando STL
#include "Peca.h"
#include "PecaMontagem.h";

using namespace std;

class MultiStack{
private:
	stack<Peca*> listaStacks[51];
public:
	MultiStack(void);
	MultiStack(const MultiStack&);
	~MultiStack(void);

	stack<Peca*> getListaStack(void) const;
	void setListaStack(const stack<Peca*>&);

	MultiStack* clone(void) const;

	const MultiStack& operator=(const MultiStack&);
	bool operator==(const MultiStack&) const;

	void listar(ostream&) const;

	float contaPeso(void) const;
	void removePeca(int);

}
	ostream& operator<<(ostream&, const MultiStack&);

#endif


//Ex 1b)

float MultiStack::contaPeso(void) const{
	stack<Peca*> aux;
	float peso=0;
	Peca* help;
	PecaMontagem *pAux;

	for(int i=1; i<=51; ++i){ //Considerei que a stack de buffer n�o conta para o c�lculo do peso, uma vez que n�o est�o compactadas
		aux= listaStacks[i];
		while(!aux.empty()){
			help=aux.top();
			if(typeid(*help)==typeid(PecaMontagem)){ //Se a pe�a retirada � do tipo PecaMontagem
				peso+=dynamic_cast<PecaMontagem*>(pAux)->getPeso(); //Faz-se o downcast de Peca* para PecaMontagem* e vai-se buscar o peso dela
			}
			aux.pop(); //retira-se essa pe�a da stack auxiliar e passa � pr�xima
		}
	}

	return peso;
}

//ex2
/*Considerei que o m�todo tamb�m vai remover objectos da primeira stack, a que serve como buffer
Assumi tamb�m que o array de stacks tem sempre 50 elementos e que, caso n�o estejam todos preenchidos
a stack correspondente fica vazia*/
void MultiStack::removePeca(int numPeca){
	stack<Peca*> aux;

	//Primeiro remover todas as pe�as com o num de pe�a igual ao passado por par�metro
	for(int i = 0; i<50; ++i){
		//Para isso, percorro stack a stack e copio para uma auxiliar os elementos dessa stack que t�m um nr diferente do que � passado
		while(!listaStacks[i].empty()){
			if(listaStacks[i].top()->getCodigo()!=numPeca){
				aux.push(listaStacks[i].top());
			}
			listaStacks[i].pop();
		}
		//Por fim, volto a colocar l� a stack que foi "filtrada" e que, � partida ter� menos elementos
		while(!aux.empty()){
			listaStacks[i].push(aux.top());
			aux.pop();
		}
	}

	//Passando ao reagrupamento, todas as stacks ter�o de ficar com 3i elementos, excepto a ultima a ter elementos que poder� ficar com menos
	//E a partir da qual, todas as stacks ficar�o vazias
	//Considerei tamb�m que a stack 0 n�o tem n�mero m�nimo de elementos
	for(int i=1; i<=50;++i){
		if(listaStacks[i].size() < 3*i){ //Se a stack actual n�o est� preenchida
			for(int j=i+1;i<=51;++i){ //Percorrer todas as que est�o para a sua frente
				while(!listaStacks[j].empty() && listaStacks[i].size() < 3*i){ //Enquanto esta stack n�o estiver vazia ou a outra totalmente preenchida...
					listaStacks[i].push(listaStacks[j].top());
					listaStacks[j].pop();
				}
			}
		}
	}
}

//Ex 3
/*
O m�todo tem complexidade n, uma vez que vai chamar-se tantas vezes quantas o n�mero de algarismos passado
*/