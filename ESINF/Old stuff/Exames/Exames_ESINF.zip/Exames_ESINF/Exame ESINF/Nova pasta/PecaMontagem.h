#ifndef PECAMONTAGEM_H
#define PECAMONTAGEM_H

#include "Peca.h"

class PecaMontagem:public Peca{
private:
	float peso;
public:
	PecaMontagem(void);
	PecaMontagem(int, float);
	PecaMontagem(const PecaMontagem&);
	~PecaMontagem(void);

	float getPeso(void) const;
	void setPeso(float);

	PecaMontagem* clone(void) const;

	const PecaMontagem& operator=(const PecaMontagem&);
	bool operator==(const PecaMontagem&) const;

	void listar(ostream&) const;
}

	ostream& operator<<(ostream&, const PecaMontagem&);

#endif