#ifndef MULTICORE_H
#define MULTICORE_H


/*Assumi que existe uma classe Nucleo cujos atributos s�o x e y (as coordenadas respectivas) e a sua capacidade de processamento
e que essa classe tem, entre outros as sobrecargas de operador ==, = e stream out*/
class MultiCore:public ListAdjGrafo<Nucleo*,int>{
private:
public:
	MultiCore(void);
	MultiCore(const Multicore&);
	virtual ~MultiCore(void);

	virtual void listar(void) const;

	/*3b*/
	int larguraBanda(const Nucleo&, const Nucleo&) const;

	/*3c*/
	void processamentoMinimo(const Nucleo&, const Nucleo&, int) const;
}

#endif

/*3b
Neste ex, daquilo que pude entender do enunciado, s�o passados dois n�cleos
e a fun��o devolve a largura de banda caso estejam directamente ligados, sen�o devolve 0*/
int MultiCore::larguraBanda(const Nucleo& n1, const Nucleo& n2) const{
	Vertice<Nucleo*, int>*vAux = encvert_key(1); // devolve a cabe�a do grafo
	Ramo<Nucleo*,int>*rAux;
	if(vAux == NULL)// verificar se o grafo est� vazio
		return 0;

	while(vAux){ //Enquanto existir vAux
		if(*(vAux->GetConteudo()) == n1){ //Se for este o que procuramos
			rAux=vAux->GetRamo(); //Procurar o ramo em que ele aponta para o segundo n�cleo
			while(rAux){
				if(*(rAux->GetVertice()->GetConteudo()) == n2) //Se existir
					return rAux->GetConteudo();	//Devolver esse conte�do

				rAux=rAux->GetRamo();//Caso contr�rio passar ao pr�ximo
			}

			return 0;	//Caso chegue ao fim do ciclo (ou seja, procurou em todos os ramos que saem daquele v�rtice
						//E n�o encontrou nenhum a apontar para um v�rtice cujo conte�do seja o procurado, ent�o retorna 0
		}
		//Se ainda n�o encontramos o v�rtice cujo conte�do seja igual a n1, continuamos a procura
		vAux = vAux->GetVertice(); //Passa ao v�rtice seguinte	
	}
	//Caso tenha percorrido todos os v�rtices e n�o tenha encontrado nenhum cujo conte�do seja igual ao de n1
	return 0;
}

/*3c*/
