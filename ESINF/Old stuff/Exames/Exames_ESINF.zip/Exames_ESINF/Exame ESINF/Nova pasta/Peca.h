#ifndef PECA_H
#define PECA_H

#include <iostream>


using namespace std;


class Peca{
private:
	int codigo;
public:
	Peca(void); //Construtor por defeito
	Peca(int); // Construtor por par�metro
	Peca(const Peca&); //Construtor por c�pia
	virtual ~Peca(void); //Destrutor, virtual para garantir que todas as classes que derivam desta o tenham tamb�m que implementar
	//Set's e Get's
	int getCodigo(void) const; //O const � para garantir que este m�todo n�o altera os atributos da classe
	void setCodigo(int); //Este, uma vez que vai alterar o c�digo, n�o pode ser const
	//Clone
	virtual Peca* clone(void) const; //Cria um ponteiro para o pr�prio objecto
	//Sobrecarga de operadores
	virtual const Peca& operator=(const Peca&);
	virtual bool operator==(const Peca&) const;

	virtual void listar(ostream&) const;
}

ostream& operator<<(ostream&, const Peca&);

#endif