#ifndef ArvBin_
#define ArvBin_

#include "Queue.h"
#include "Nodo.h"

template<class T> 
class ArvBinPesq ;

template<class T>
class ArvBin 
{
   	friend ArvBinPesq<T>;

	private:
      Nodo<T>* raiz;  
 	  
	  Nodo<T>* copiar(Nodo<T>* rz);
	  void destroiArv(Nodo<T>* rz);

	  Nodo<T>* pesquisa(const T& x, Nodo<T>* rz) const;
      Nodo<T>* pesquisaAnt(const T& x, Nodo<T>* rz) const ;

	  void preOrdem(Nodo<T>* rz) const ;
	  void posOrdem(Nodo<T>* rz) const ;
	  void emOrdem(Nodo<T>* rz) const ;
	  void listarPorNivel(Nodo<T>* rz) const ;

	  int altura(Nodo<T>* rz) const ;

   public:
      ArvBin() ;
	  ArvBin(const ArvBin<T> &arv) ;
	  ~ArvBin(); 
	  
	  void fazerArv(const T &elem, ArvBin<T> &a1, ArvBin<T> &a2) ;

	  bool vazia() const ;

	  void preOrdem() const ;
	  void posOrdem() const ;
	  void emOrdem() const ;
	  void listarPorNivel() const ;

	  void altura() const ;

	  bool pesquisa(T &x) const ;

	  void eliminar(const T &x) ;

	  /*Ex5*/
	  bool verificaCheia(Nodo<T>*) const;
};

//Construtor por defeito 
template<class T>
ArvBin<T>::ArvBin()
{
	raiz = NULL;
}

template<class T>
Nodo<T>* ArvBin<T>::copiar(Nodo<T>* rz) 
{
	if (rz == NULL)
		return NULL;

	Nodo<T>* n = new Nodo<T>;
	
	n->inf = rz->inf ;
	n->esq=copiar(rz->esq);
	n->dir=copiar(rz->dir);
	
	return n;
}

// Construtor copia
template<class T>
ArvBin<T>::ArvBin(const ArvBin<T>& arv) 
{	
	raiz=copiar(arv.raiz);	
}

template<class T>
void ArvBin<T>::destroiArv(Nodo<T>* rz)
{
	if (rz != NULL)
	{
		destroiArv(rz->esq);
		destroiArv(rz->dir);
		delete rz;
	}
}

template<class T>
ArvBin<T>::~ArvBin()
{
	destroiArv(raiz) ;
	raiz = NULL ;
}


template<class T>
bool ArvBin<T>::vazia() const
{
	return (raiz==NULL);
}


template<class T>
void ArvBin<T>::preOrdem() const
{ 
	   cout << "\nVisita Pre-ordem \n" ; 
	   preOrdem(this->raiz);
}

template <class T>
void ArvBin<T>::preOrdem(Nodo<T>* rz) const
{
	if (rz!=NULL)
	{
		cout << rz->inf << " "; 
		preOrdem(rz->esq);
		preOrdem(rz->dir);
	}
}

template<class T>
void ArvBin<T>::posOrdem() const
{ 
	  cout << "\nVisita Pos-ordem  \n" ; 
	  posOrdem(this->raiz); 
}

template <class T>
void ArvBin<T>::posOrdem(Nodo<T>* rz) const
{
	if (rz!=NULL)
	{ 
		posOrdem(rz->esq);
		posOrdem(rz->dir);
		cout<< rz->inf << " " ;
	}
}

template<class T>
void ArvBin<T>::emOrdem() const
{ 
	cout << "\nVisita em Ordem (ou Simetrica) \n" ; 
	emOrdem(this->raiz);  
}

template <class T>
void ArvBin<T>::emOrdem(Nodo<T>* rz) const
{
	if (rz!=NULL)
	{
		emOrdem(rz->esq);
		cout << rz->inf << " " ; 
		emOrdem(rz->dir);
	}
	return;
}

template <class T>
void ArvBin<T>::listarPorNivel() const
{
	cout << "\nVisita por Niveis \n" ; 
	listarPorNivel(raiz);
}

template <class T>
void ArvBin<T>::listarPorNivel(Nodo<T>* rz) const
{	
	Queue<Nodo<T>* > q;
	Nodo<T>* p;

	if (rz != NULL)
		q.insere(rz);

	while (!q.vazia())
	{
		q.retira(p);
        cout << p->inf << " " ;
  		if (p->esq != NULL)
		    q.insere(p->esq);  
  		if (p->dir != NULL)
			q.insere(p->dir);
	}
}


template <class T>
void ArvBin<T>::altura() const
{
	cout << "\nAltura Arvore : " << altura(raiz) ;
}

template <class T>
int ArvBin<T>::altura(Nodo<T>* rz) const
{
	int nesq, ndir ;

	if (rz == NULL)
		return -1 ;
	else
	{
	    nesq = altura(rz->esq) ;
		ndir = altura(rz->dir) ;
    	
		return (nesq > ndir ? nesq+1:ndir+1);
	}
}

// Constroi uma Arv Bin das folhas para a raiz 
template<class T>
void ArvBin<T>::fazerArv(const T& elem, ArvBin<T>& a1, ArvBin<T>& a2)
{
	raiz = new Nodo<T>(elem,a1.raiz,a2.raiz);
	a1.raiz=NULL; 
	a2.raiz=NULL; 
}


template<class T>
Nodo<T>* ArvBin<T>::pesquisa(const T& x, Nodo<T>* rz) const
{
	Nodo<T>* n;
	
	if (rz)
	{
		if(rz->inf == x)
			return rz;
		
		n=pesquisa(x,rz->esq);
		
		if(n == NULL)
		  n=pesquisa(x,rz->dir);
		
		return n;
	}
	else 
		return NULL;
}

template<class T>
bool ArvBin<T>::pesquisa(T& x) const 
{
    Nodo<T>* ap = pesquisa(x,raiz);

	if (ap) 
	{
		if (ap->inf == x) 
		  x = ap->inf ;
	    
		return true ;
	}
	else
	  return false ;
}


template<class T>
Nodo<T>* ArvBin<T>::pesquisaAnt(const T& x, Nodo<T>* rz) const
{
	Nodo<T>* n;

	if (rz == NULL)
		return rz;
	if (rz->esq != NULL)
		if (rz->esq->inf == x)
			return rz;
	if (rz->dir != NULL)
		if (rz->dir->inf == x)
			return rz;
	
	n=pesquisaAnt(x,rz->esq);
	
	if (n == NULL)
		n=pesquisaAnt(x,rz->dir);
	
	return n;
}

// Elimina a subarvore cuja raiz=x. 

template<class T>
void ArvBin<T>::eliminar(const T &x) 
{
   Nodo<T>* ant ;

   ant = pesquisaAnt(x,raiz);
  
   if (ant == NULL)
   {	   
	   if (raiz->inf == x)  //elimina toda a arvore
       {
         destroiArv(raiz);
         raiz = NULL ; 
	   }
	   else
		   cout << "Elem a eliminar nao existe " << endl ; 
   }
   else	//elimina subarvore
   {
	   if (ant->esq)
         if (ant->esq->inf == x)
		 {
		   destroiArv(ant->esq);   
	       ant->esq = NULL ;
		 }
	     else
			 if (ant->dir)
	           if (ant->dir->inf == x)
			   {
		          destroiArv(ant->dir);
	              ant->dir = NULL ;
			   }
   }
}


/*Exerc�cio 5*/
template<class T>
bool ArvBin<T>::verificaCheia(Nodo<T>* rz) const{
	if(!rz)
		return true;

	if(!raiz->dir || !raiz->esq)
		return false;

	//return(verificaCheia(rz->dir) && verificaCheia(rz->esq));
	verificaCheia(rz->dir);
	verificaCheia(rz->esq);

}

#endif