class pais{


private: string nome, continente;
		 set<string>idiomas;
public:
	pais();
	pais(const pais& a);
	~pais();


};