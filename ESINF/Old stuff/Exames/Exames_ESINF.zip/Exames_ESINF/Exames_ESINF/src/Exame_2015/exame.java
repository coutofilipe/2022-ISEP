/*
 * LEI-ISEP 2016/2017 - 2º Ano Licenciatura
 * LAPR3
 */
package Exame_2015;

import AdjacencyMapGraph.Graph;
import AdjacencyMapGraph.GraphAlgorithms;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;

/**
 *
 * @author Tiago Ferreira <1150556@isep.ipp.pt>
 * @author Ricardo Sousa <1150784@isep.ipp.pt>
 * @author Paulo Coelho <1100458@isep.ipp.pt>
 * @author Rui Braga <1150835@isep.ipp.pt>
 * @author Luís Oliveira <1150773@isep.ipp.pt>
 */
public class exame {

    public static void main(String[] args) {
        List<String> dest1 = new ArrayList<>();
        dest1.add("Tiago");
        dest1.add("Sarapalo");
        dest1.add("Piu");
        dest1.add("Jorge Miguel");

        List<String> dest2 = new ArrayList<>();
        dest2.add("Burgos");
        dest2.add("Barrado");
        dest2.add("85");

        Mensagem m1 = new Mensagem("ISEP", dest1, "Notas", "Passaram a tudo, muito bem!");
        Mensagem m2 = new Mensagem("FEUP", dest1, "Ingresso", "Por favor entrem na feup, pls...");
        Mensagem m3 = new Mensagem("Touras.com", dest1, "Malhação", "Queremos malhar");
        Mensagem m4 = new Mensagem("ISEP", dest1, "Ostentação", "Festa d'Ostentação, feita por mim, Angeloni.");
        Mensagem m5 = new Mensagem("ISEP", dest1, "Atenção", "O mouco é do crl");
        Mensagem m6 = new Mensagem("Angeloni", dest2, "Praxe", "Fascistas.");
        Mensagem m7 = new Mensagem("Bitaites", dest2, "Plano de Praxe", "lol.jk");

        List<Mensagem> out = new ArrayList<>();
        out.add(m1);
        out.add(m2);
        out.add(m3);
        out.add(m4);
        out.add(m5);
        out.add(m6);
        out.add(m7);

        List<Mensagem> in = new ArrayList<>();

        Servidor s1 = new Servidor(in, out);

        System.out.println("EX.01 A)");
        List<Mensagem> sentMsg = sentMessages("ISEP", s1);

        for (Mensagem m : sentMsg) {
            System.out.println(m.toString() + "\n---------------");
        }

        System.out.println("\nEX.01 B)");
        List<Mensagem> mostDest = mostDest(s1);

        for (Mensagem m : mostDest) {
            System.out.println(m.assunto);
        }

        System.out.println("\nEX.01 C)");
        s1.cxout = deleteSubject(s1, "Malhação");

        for (Mensagem m : s1.cxout) {
            System.out.println(m.assunto);
        }

        System.out.println("\nEX.3 B)");
        Graph<String, Double> grafo = new Graph<>(true);

        grafo.insertVertex("Porto");
        grafo.insertVertex("Lisboa");
        grafo.insertVertex("Faro");
        grafo.insertVertex("Madrid");
        grafo.insertVertex("Barcelona");
        grafo.insertVertex("Roma");
        grafo.insertVertex("Paris");
        grafo.insertVertex("Londres");
        grafo.insertVertex("Moscovo");

        grafo.insertEdge("Porto", "Lisboa", 17.00, 60);
        grafo.insertEdge("Porto", "Faro", 22.00, 60);
        grafo.insertEdge("Porto", "Madrid", 26.00, 70);
        grafo.insertEdge("Porto", "Barcelona", 23.00, 100);
        grafo.insertEdge("Porto", "Paris", 148.00, 135);
        grafo.insertEdge("Porto", "Londres", 45.00, 145);
        grafo.insertEdge("Porto", "Moscovo", 850.00, 320);

        grafo.insertEdge("Lisboa", "Barcelona", 98.00, 105);
        grafo.insertEdge("Lisboa", "Madrid", 29.00, 75);
        grafo.insertEdge("Lisboa", "Porto", 17.00, 55);
        grafo.insertEdge("Lisboa", "Faro", 151.00, 40);
        grafo.insertEdge("Lisboa", "Paris", 127.00, 150);
        grafo.insertEdge("Lisboa", "Londres", 35.00, 160);
        grafo.insertEdge("Lisboa", "Moscovo", 733.00, 355);

        grafo.insertEdge("Faro", "Porto", 37.00, 70);
        grafo.insertEdge("Faro", "Barcelona", 98.00, 75);
        grafo.insertEdge("Faro", "Paris", 138.00, 180);
        grafo.insertEdge("Faro", "Londres", 296.00, 160);

        grafo.insertEdge("Madrid", "Barcelona", 23.00, 75);
        grafo.insertEdge("Madrid", "Paris", 61.00, 125);
        grafo.insertEdge("Madrid", "Moscovo", 523.00, 310);

        grafo.insertEdge("Barcelona", "Paris", 56.00, 120);
        grafo.insertEdge("Barcelona", "Roma", 40.00, 115);

        grafo.insertEdge("Roma", "Paris", 56.00, 120);
        grafo.insertEdge("Roma", "Londres", 63.00, 165);
        grafo.insertEdge("Roma", "Moscovo", 201.00, 280);

        grafo.insertEdge("Paris", "Londres", 50.00, 70);
        grafo.insertEdge("Paris", "Roma", 120.00, 120);
        grafo.insertEdge("Paris", "Moscovo", 119.00, 260);

        grafo.insertEdge("Londres", "Moscovo", 221.00, 220);

        List<LinkedList<String>> paths = returnIt(grafo, "Porto", 240, 250);

//        
        for (LinkedList<String> path : paths) {
            for (String v : path) {
                System.out.print(v + " > ");
            }
            System.out.print("Custo: " + getCost(grafo, path) + "€ | Tempo: " + getTime(grafo, path) + " min.\n");
        }

    }

    // EXERCICIO 1
    private static class Mensagem implements Comparable<Mensagem> {

        public String remetente;
        public List<String> destinatarios;
        public String assunto;
        public String texto;

        public Mensagem() {
            remetente = "DESCONHECIDO";
            destinatarios = new LinkedList<>();
            assunto = "SEM ASSUNTO";
            texto = "-";
        }

        public Mensagem(String r, List<String> d, String a, String t) {
            remetente = r;
            destinatarios = d;
            assunto = a;
            texto = t;
        }

        @Override
        public String toString() {
            return "De: " + remetente + ";\nPara: " + destinatarios.size() + " destinatarios;\nAssunto: " + assunto + "\n" + texto;
        }

        @Override
        public int compareTo(Mensagem m) {
            return assunto.compareTo(m.assunto);
        }
    }

    private static class Servidor {

        public List<Mensagem> cxin;
        public List<Mensagem> cxout;

        public Servidor() {
            cxin = new LinkedList<>();
            cxout = new LinkedList<>();
        }

        public Servidor(List<Mensagem> i, List<Mensagem> o) {
            cxin = i;
            cxout = o;
        }
    }

    public static List<Mensagem> sentMessages(String user, Servidor sv) {
        List<Mensagem> user_msg = new ArrayList<>();
        Iterator<Mensagem> it = sv.cxout.iterator();

        while (it.hasNext()) {
            Mensagem m = it.next();
            if (m.remetente == user) {
                user_msg.add(m);
            }
        }

        Collections.sort(user_msg);

        return user_msg;
    }

    public static List<Mensagem> mostDest(Servidor sv) {
        List<Mensagem> ret = new ArrayList<>();
        Iterator<Mensagem> it = sv.cxout.iterator();
        int maior = it.next().destinatarios.size();

        while (it.hasNext()) {
            if (it.next().destinatarios.size() > maior) {
                maior = it.next().destinatarios.size();
            }
        }

        it = sv.cxout.iterator();

        while (it.hasNext()) {
            Mensagem m = it.next();
            if (m.destinatarios.size() == maior) {
                ret.add(m);
            }
        }

        return ret;
    }

    public static List<Mensagem> deleteSubject(Servidor sv, String assunto) {
        List<Mensagem> ret = new ArrayList<>();
        Iterator<Mensagem> it = sv.cxout.iterator();

        while (it.hasNext()) {
            Mensagem m = it.next();
            if (m.assunto != assunto) {
                ret.add(m);
            }
        }

        return ret;
    }
    // FIM EXERCICIO 1

    //EXERCICIO 3
    public static List<LinkedList<String>> returnIt(Graph<String, Double> grafo, String origem, double preço, double minutos) {
        List<LinkedList<String>> ret = new ArrayList<LinkedList<String>>();
        for (String dest : grafo.vertices()) {
            if (dest != origem) {
                ArrayList<LinkedList<String>> path = GraphAlgorithms.allPaths(grafo, origem, dest);
                for (LinkedList<String> p : path) {
                    if (p.size() > 2 && getCost(grafo, p) <= preço && getTime(grafo, p) <= minutos) {
                        ret.add(p);
                    }
                    
                }
            }
        }

        return ret;
    }

    public static double getCost(Graph<String, Double> grafo, LinkedList<String> path) {
        double total = 0;

        for (int i = 0; i < path.size() - 1; i++) {
            total += grafo.getEdge(path.get(i), path.get(i + 1)).getElement();
        }

        return total;
    }

    public static double getTime(Graph<String, Double> grafo, LinkedList<String> path) {
        double total = 0;

        for (int i = 0; i < path.size() - 1; i++) {
            total += grafo.getEdge(path.get(i), path.get(i + 1)).getWeight();
        }

        return total;
    }
    //FIM EXERCICIO 3

}
