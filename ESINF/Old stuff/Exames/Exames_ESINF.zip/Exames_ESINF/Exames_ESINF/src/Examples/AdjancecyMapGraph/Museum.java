
package Examples.AdjancecyMapGraph;

import AdjacencyMapGraph.*;
import static AdjacencyMapGraph.GraphAlgorithms.*;
import java.util.ArrayList;
import java.util.LinkedList;
 

/**
 *
 * DEI-ESINF
 */

public class Museum { 
    
    //------------ Static nested Room class ------------
    
    public static class Room implements Comparable {
       
        private Integer number;
        private Double time;
        
        public Room (Integer n, Double t) {number=n; time=t;}
        
        public Integer getNumber() {return number;}
        public void setNumber(Integer n) {number=n;}
        
        Double getTime() {return time;}
        public void setTime(Double t) {time=t;}
        
        public int compareTo(Object otherObject) {
        
            Room otherRoom = (Room) otherObject ;
            if (this.time < otherRoom.time)  return -1;
            if (this.time == otherRoom.time) return 0;
            return 1;
        }
        
        @Override
        public boolean equals(Object otherObj) {
            if (this == otherObj){
                return true;
            }
            if (otherObj == null || this.getClass() != otherObj.getClass()){
                return false;
            }
            Room otherRoom = (Room) otherObj;
        
            return this.number == otherRoom.number;
        }
        
        @Override
        public String toString() {
            String st="";
            st+= "Room: "+number+" (Time: "+time+")" ;
            return st;
    } 
    
    }
    //------------ end of Static nested Room class ------------
    
    private Graph<Room,Integer> exhibition;
    
    public Museum (){
        exhibition = new Graph<>(false) ;
    }
    
    public void addtwoConnectedRooms(Integer n1, Double t1, Integer n2, Double t2){
       
        throw new UnsupportedOperationException("Not supported yet.");
    }
    
    public double timevisitAllrooms(){
        
        throw new UnsupportedOperationException("Not supported yet.");
    }
    
    public double timeOnevisit(LinkedList<Room> visit){
        
        throw new UnsupportedOperationException("Not supported yet.");
    }
    
    public ArrayList<LinkedList<Room>> visitwithLimitedtime (Integer n1, Double t1, Integer n2, Double t2, double time){
    
        throw new UnsupportedOperationException("Not supported yet.");
    }
        
    public LinkedList<Room> visitwithAllrooms (Integer n1, Double t1){
    
        throw new UnsupportedOperationException("Not supported yet.");
    }
    
    @Override
    public String toString() {
        return exhibition.toString();
    } 
    
}


