/*
* A collection of graph algorithms.
*/
package AdjacencyMapGraph;

import java.util.ArrayList;
import java.util.LinkedList;

/**
 *
 * @author DEI-ESINF
 */

public class GraphAlgorithms {
    
   /**
   * Performs breadth-first search of a Graph starting in a Vertex 
   * @param g Graph instance
   * @param vInf information of the Vertex that will be the source of the search
   * @return qbfs a queue with the vertices of breadth-first search 
   */
    public static<V,E> LinkedList<V> BreadthFirstSearch(Graph<V,E> g, V vert){
    
        if (!g.validVertex(vert)) 
           return null; 
        
        LinkedList<V> qbfs = new LinkedList<>(); 
        LinkedList<V> qaux = new LinkedList<>();
        boolean[] visited = new boolean[g.numVertices()];  //default initializ.: false

        qbfs.add(vert);
        qaux.add(vert);
        int vKey=g.getKey(vert);
        visited[vKey]=true;
       
        while(!qaux.isEmpty()){
            vert=qaux.remove(); 
            for (Edge<V,E> edge : g.outgoingEdges(vert)){                
                V vAdj = g.opposite(vert, edge);
                vKey = g.getKey(vAdj);
                if (!visited[vKey]){
                    qbfs.add(vAdj);
                    qaux.add(vAdj);
                    visited[vKey]=true;
                }
            }
        }
        return qbfs;
    }
   
   //DFS:
    /**
     * Performs depth-first search starting in a Vertex
     *
     * @param g Graph instance
     * @param vOrig Vertex of graph g that will be the source of the search
     * @param visited set of discovered vertices
     * @param qdfs queue with vertices of depth-first search
     */
    private static <V, E> void DepthFirstSearch(Graph<V, E> g, V vOrig, boolean[] visited, LinkedList<V> qdfs) {

        qdfs.add(vOrig);
        int vKey = g.getKey(vOrig);
        visited[vKey] = true;

        for (Edge<V, E> edge : g.outgoingEdges(vOrig)) {
            V vAdj = g.opposite(vOrig, edge);
            vKey = g.getKey(vAdj);
            if (!visited[vKey]) {
                DepthFirstSearch(g, vAdj, visited, qdfs);
            }
        }
    }

    /**
     * @param g Graph instance
     * @param vInf information of the Vertex that will be the source of the
     * search
     * @return qdfs a queue with the vertices of depth-first search
     */
    public static <V, E> LinkedList<V> DepthFirstSearch(Graph<V, E> g, V vert) {

        if (!g.validVertex(vert)) {
            return null;
        }

        LinkedList<V> qdfs = new LinkedList<>();
        boolean[] visited = new boolean[g.numVertices()];

        DepthFirstSearch(g, vert, visited, qdfs);

        return qdfs;
    }
   
    //allPaths:
    /**
     * Returns all paths from vOrig to vDest
     *
     * @param g Graph instance
     * @param vOrig Vertex that will be the source of the path
     * @param vDest Vertex that will be the end of the path
     * @param visited set of discovered vertices
     * @param path stack with vertices of the current path (the path is in
     * reverse order)
     * @param paths ArrayList with all the paths (in correct order)
     */
    private static <V, E> void allPaths(Graph<V, E> g, V vOrig, V vDest, boolean[] visited,
            LinkedList<V> path, ArrayList<LinkedList<V>> paths) {

        path.push(vOrig);
        int vKey = g.getKey(vOrig);
        visited[vKey] = true;

        for (Edge<V, E> edge : g.outgoingEdges(vOrig)) {
            V vAdj = g.opposite(vOrig, edge);
            if (vAdj == vDest) {
                path.push(vAdj);
                LinkedList<V> revpath = revPath(path);
                paths.add(new LinkedList(revpath));  //save clone of reverse path
                path.pop();
            } else {
                vKey = g.getKey(vAdj);
                if (!visited[vKey]) {
                    allPaths(g, vAdj, vDest, visited, path, paths);
                }
            }
        }
        visited[vKey] = false;
        path.pop();
    }
    
   /**
     * @param g Graph instance
     * @param voInf information of the Vertex origin
     * @param vdInf information of the Vertex destination
     * @return paths ArrayList with all paths from voInf to vdInf
     */
    public static <V, E> ArrayList<LinkedList<V>> allPaths(Graph<V, E> g, V vOrig, V vDest) {

        LinkedList<V> path = new LinkedList<>();
        ArrayList<LinkedList<V>> paths = new ArrayList<>();
        boolean[] visited = new boolean[g.numVertices()];

        if (g.validVertex(vOrig) && g.validVertex(vDest)) {
            allPaths(g, vOrig, vDest, visited, path, paths);
        }

        return paths;
    }
    
   //Dikstra:
    /**
     * Computes shortest-path distance from a source vertex to all reachable
     * vertices of a graph g with nonnegative edge weights This implementation
     * uses Dijkstra's algorithm
     *
     * @param g Graph instance
     * @param vOrig Vertex that will be the source of the path
     * @param visited set of discovered vertices
     * @param pathkeys minimum path vertices keys
     * @param dist minimum distances
     */
    private static <V, E> void shortestPathLength(Graph<V, E> g, V vOrig, V[] vertices,
            boolean[] visited, int[] pathKeys, double[] dist) {
        for (int i = 0; i < g.numVertices(); i++) {
            dist[i] = Double.MAX_VALUE;
            pathKeys[i] = -1;
            visited[i] = false;
        }
        dist[g.getKey(vOrig)] = 0;
        int idx = g.getKey(vOrig);
        while (idx != -1) {
            visited[idx] = true;
            for (Edge<V, E> outgoingEdge : g.outgoingEdges(vertices[idx])) {
                int i = g.getKey(outgoingEdge.getVDest());
                if (visited[i] == false && dist[i] > dist[idx] + g.getEdge(vertices[idx], vertices[i]).getWeight()) {
                    dist[i] = dist[idx] + g.getEdge(vertices[idx], vertices[i]).getWeight();
                    pathKeys[i] = idx;

                }
            }

            int indiceAux = idx;
            double distanciaMinima = Double.MAX_VALUE;
            for (int i = 0; i < dist.length; i++) {

                if (visited[i] == false) {
                    if (dist[i] < distanciaMinima) {
                        distanciaMinima = dist[i];
                        idx = i;

                    }
                }
                if (i == dist.length - 1 && idx == indiceAux) {
                    idx = -1;
                }

            }
        }

    }
    
    /**
     * Extracts from pathKeys the minimum path between voInf and vdInf The path
     * is constructed from the end to the beginning
     *
     * @param g Graph instance
     * @param voInf information of the Vertex origin
     * @param vdInf information of the Vertex destination
     * @param pathkeys minimum path vertices keys
     * @param path stack with the minimum path (correct order)
     */
    private static <V, E> void getPath(Graph<V, E> g, V vOrig, V vDest, V[] verts, int[] pathKeys, LinkedList<V> path) {
        path.addFirst(vDest);
        V aux = verts[pathKeys[g.getKey(vDest)]];
        while (g.getKey(aux) != (g.getKey(vOrig))) {
            path.addFirst(aux);
            aux = verts[pathKeys[g.getKey(aux)]];
        }
        path.addFirst(vOrig);

    }

    //shortest-path between voInf and vdInf
    public static <V, E> double shortestPath(Graph<V, E> g, V vOrig, V vDest, LinkedList<V> shortPath) {
        if (g.validVertex(vDest) && g.validVertex(vOrig)) {
            if (vOrig.equals(vDest)) {
                shortPath.add(vDest);
                return 0;
            }
            V[] vertices = g.allkeyVerts();
            boolean[] visited = new boolean[g.numVertices()];
            int[] pathKeys = new int[g.numVertices()];
            double[] dist = new double[g.numVertices()];
            shortestPathLength(g, vOrig, vertices, visited, pathKeys, dist);
            if (pathKeys[g.getKey(vDest)] != -1) {
                getPath(g, vOrig, vDest, vertices, pathKeys, shortPath);
            }

            return dist[g.getKey(vDest)];
        }
        return 0;
    }
   
    /**
     * Reverses the path
     * @param path stack with path
     */
    private static<V,E> LinkedList<V> revPath(LinkedList<V> path){ 
   
        LinkedList<V> pathcopy = new LinkedList<>(path);
        LinkedList<V> pathrev = new LinkedList<>();
        
        while (!pathcopy.isEmpty())
            pathrev.push(pathcopy.pop());
        
        return pathrev ;
    }    
}