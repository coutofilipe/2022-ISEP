/*
 * LEI-ISEP 2016/2017 - 2º Ano Licenciatura
 * LAPR3
 */
package Exame_2017;

import BST.BST;
import AdjacencyMapGraph.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

/**
 *
 * @author Tiago Ferreira <1150556@isep.ipp.pt>
 * @author Ricardo Sousa <1150784@isep.ipp.pt>
 * @author Paulo Coelho <1100458@isep.ipp.pt>
 * @author Rui Braga <1150835@isep.ipp.pt>
 * @author Luís Oliveira <1150773@isep.ipp.pt>
 */
public class metodos {
    
    public Map<Integer,LinkedList<Integer>> KsubLists(LinkedList<Integer> list, ArrayList<Integer> centers) {
        
        Map<Integer,LinkedList<Integer>> map = new HashMap<Integer,LinkedList<Integer>>();
                
        Collections.sort(centers); // ordena lista de centros para percorre los do mais baixo para o mais alto                         
        
        for (int i = 0; i < centers.size(); i++) {
            LinkedList<Integer> subList = new LinkedList<Integer>();
            for (int j = 0; j < list.size(); j++) {    
                int num = list.get(j);
                if(i == centers.size() - 1) {
                    subList.add(num);
                }else if(Math.abs(centers.get(i) - num) < Math.abs(centers.get(i+1) - num)){
                    subList.add(num);
                    list.remove(j);
                    j--;
                }
            }
            map.put(centers.get(i), subList);
        }  
        
        return map;
    }
   
    public Object searchNode(BST tree, String path) {
        
        if(path.isEmpty() == true) {
            return tree.root().getElement();
        }
                       
        if(path.charAt(0) == '1') {
            if(tree.root.getRight().getElement() == null){
                return null;
            }
            tree.root = tree.root().getRight();
            return searchNode(tree,path.substring(1));
        } else {
            if(tree.root.getLeft().getElement() == null){
                return null;
            }
            tree.root = tree.root().getLeft();
            return searchNode(tree,path.substring(1));
        }
    }
    
    public List<String> calculaPromocoes(Graph<String,Integer> g, Integer n) {
        
        if(n==0) {
            return null;
        }
        
        List<String> list = GraphAlgorithms.BreadthFirstSearch(g, "Maria");
        LinkedList<String> ret = new LinkedList<String>();
        
        ret.add("João");
        
        
        for (int i = 0; i < n-1; i++) {
            ret.add(list.get(i));
        }
        
        return ret;
    }
    
    
    public int getSubHeap(int idx, Integer[] vet) {
        int total = 0;
        if(vet[idx] == null) {
            return 0;
        }
        int left_i = (2*idx)+1, right_i = (2*idx) + 2;
        
        if(left_i < vet.length){
            total += getSubHeap(left_i, vet);
        }
        if(right_i < vet.length) {
            total += getSubHeap(right_i,vet);
        }
        return total+1;
    }
    
}
