/*
 * LEI-ISEP 2016/2017 - 2º Ano Licenciatura
 * LAPR3
 */
package Exame_2017;

import AdjacencyMapGraph.Edge;
import AdjacencyMapGraph.Graph;
import BST.BST;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

/**
 *
 * @author Tiago Ferreira <1150556@isep.ipp.pt>
 * @author Ricardo Sousa <1150784@isep.ipp.pt>
 * @author Paulo Coelho <1100458@isep.ipp.pt>
 * @author Rui Braga <1150835@isep.ipp.pt>
 * @author Luís Oliveira <1150773@isep.ipp.pt>
 */
public class main {
    
    public static void main(String[]args) {
        
        LinkedList<Integer> lista = new LinkedList<Integer>();
        ArrayList<Integer> centers = new ArrayList<Integer>();
        
        centers.add(3);
        centers.add(6);
        centers.add(10);
        
        int[] vec = {2,9,7,5,10,15,6,12,3};
        
        for(int i = 0; i<vec.length;i++) {
            lista.add(vec[i]);
        }
        
        metodos m = new metodos();
        
        Map<Integer,LinkedList<Integer>> map = m.KsubLists(lista, centers);
        
        System.out.println("Ex01:");
        for(Integer k : map.keySet()) {
            System.out.println("\nCenter: " +k);
            for(Integer v : map.get(k)) {
                System.out.print(v+" ; ");
            }
        }
        
        BST tree = new BST();
        tree.insert(65);
        tree.insert(54);
        tree.insert(85);
        tree.insert(19);
        tree.insert(60);
        tree.insert(80);
        tree.insert(89);
        tree.insert(8);
        tree.insert(35);
        tree.insert(70);
        tree.insert(83);

        String s = "101";
        
        Object o = m.searchNode(tree, s);
        
        System.out.println("\n\nEx03:");
        System.out.println("O elemento retornado por este metodo é " + o + "\n");
        
        System.out.println("Ex05:\n");
        
        Integer[] vet = {10,9,5,8,7,4,3,1,2,6};
        
        System.out.println(m.getSubHeap(1, vet));
        
        Graph<String,Integer> g = new Graph<>(true);
        String maria = "Maria";
        String joao = "João";
        String manuel = "Manuel";
        String rita  = "Rita";
        String joana = "Joana";
        String raul = "Raul";
        String antonio = "António";
        String tiago = "Tiago";
        String miguel = "Miguel";
        g.insertVertex(maria);
        g.insertVertex(joao);
        g.insertVertex(manuel);
        g.insertVertex(rita);
        g.insertVertex(joana);
        g.insertVertex(raul);
        g.insertVertex(antonio);
        g.insertVertex(tiago);
        g.insertVertex(miguel);
        g.insertEdge(maria, manuel,1,1);
        g.insertEdge(maria, rita, 2,1);
        g.insertEdge(joao, rita, 3,1);
        g.insertEdge(rita, joana, 4,1);
        g.insertEdge(rita, raul, 5,1);
        g.insertEdge(rita, antonio, 6,1);
        g.insertEdge(manuel, miguel, 7,1);
        g.insertEdge(joana, miguel, 8,1);
        g.insertEdge(raul, miguel, 9,1);
        g.insertEdge(antonio, tiago, 10,1);
        
        System.out.println("\nEx04:");
        
        List<String> l = m.calculaPromocoes(g, 3);
        
        for (int i = 0; i < l.size(); i++) {
            System.out.println(l.get(i));
        }
    }
    
}
