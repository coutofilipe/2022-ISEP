/*
 * LEI-ISEP 2016/2017 - 2º Ano Licenciatura
 * LAPR3
 */
package Exame_2016;

import AdjacencyMapGraph.Graph;
import AdjacencyMapGraph.GraphAlgorithms;
import BST.BST;
import BST.BST.Node;
import Collections.DoublyLinkedList;
import Priority_queue.HeapPriorityQueue;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Map;

/**
 *
 * @author Tiago Ferreira <1150556@isep.ipp.pt>
 * @author Ricardo Sousa <1150784@isep.ipp.pt>
 * @author Paulo Coelho <1100458@isep.ipp.pt>
 * @author Rui Braga <1150835@isep.ipp.pt>
 * @author Luís Oliveira <1150773@isep.ipp.pt>
 */
public class exame_normal {
    
    public static void main(String[]args) {
        
        
        System.out.println("EX.1");
        LinkedList<Integer> serie = new LinkedList<>();
        serie.add(2);
        serie.add(4);
        serie.add(3);
        serie.add(7);
        serie.add(8);
        serie.add(10);
        
        serie = calcMMS(serie,3);
        
        for(Integer i : serie) {
            System.out.print(i + " ");
        }
        
        System.out.println("\nEX.2");
        
    }
    
    public static LinkedList<Integer> calcMMS(LinkedList<Integer> serie, Integer periodo) {
        Integer sum = 0;
        int contador = 0;
        LinkedList<Integer> aux = new LinkedList<>();
        for (int i = 0; i < serie.size(); i++) {
            if(i>=periodo-1){
                while(contador<periodo){
                    sum += serie.get(i-contador);
                    contador++;
                }
                aux.add(sum/periodo);
                contador = 0;
                sum = 0;
            }else {
                aux.add(0);
            }
        }
        return aux;
    }
    
    public static Double centersGraph (Graph<Integer,Double> g, ArrayList<Integer> lstcenters) {
        Map<Integer,Double> map = new HashMap<>();
        double maior = 0;
        double size = 0;
        Integer temp = 0;
        
        for(Integer origem : g.vertices()) {
            for(Integer dest : g.vertices()) {
                if(origem != dest) {       
                    LinkedList<Integer> shortpath = new LinkedList<>();
                    size = GraphAlgorithms.shortestPath(g, origem, dest, shortpath);
                    if(maior < size) {
                        temp = origem;
                        maior = size;
                    }                    
                }
            }
            map.put(temp, maior);
        }
        
        Double menor = Double.MAX_VALUE;
        
        Iterator<Integer> it = map.keySet().iterator();
        
        while(it.hasNext()) {
            Integer k = it.next();
            Double v = map.get(k);
            if(v.doubleValue() <= menor) {
                menor = v.doubleValue();
                lstcenters.add(k);
            }
        }
        
        return menor;
    }
    
    public static LinkedList<Integer> lastLevel (BST tree) {
        Map<Integer,LinkedList<Integer>> map = tree.nodesByLevel();
        LinkedList<Integer> list = new LinkedList<>();
        for(Integer v : map.get(tree.height() - 1)) {
            list.add(v);
        }
        return list;
    }
    
    public static LinkedList<Integer> lowHeap (HeapPriorityQueue<Integer,Integer> heap, Integer n) {
        LinkedList<Integer> list = new LinkedList<>();
        
        while(n > 0) {
            list.add(heap.min().getValue());
            n--;
        }
        
        return list;
    }
}
