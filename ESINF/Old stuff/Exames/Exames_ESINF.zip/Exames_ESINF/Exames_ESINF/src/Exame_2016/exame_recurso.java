/*
 * LEI-ISEP 2016/2017 - 2º Ano Licenciatura
 * LAPR3
 */
package Exame_2016;

import AdjacencyMapGraph.Edge;
import AdjacencyMapGraph.Graph;
import BST.BST;
import Collections.DoublyLinkedList;
import Priority_queue.HeapPriorityQueue;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 *
 * @author Tiago Ferreira <1150556@isep.ipp.pt>
 * @author Ricardo Sousa <1150784@isep.ipp.pt>
 * @author Paulo Coelho <1100458@isep.ipp.pt>
 * @author Rui Braga <1150835@isep.ipp.pt>
 * @author Luís Oliveira <1150773@isep.ipp.pt>
 */
public class exame_recurso {

    public static void main(String[] args) {
        LinkedList<String> list = new LinkedList<>();

        list.add("Teste");
        list.add("teste");
        list.add("Teste2");
        list.add("poh");
        list.add("Teste2");

        Set<String> dic = new LinkedHashSet<String>();
        dic.add("Teste");
        dic.add("teste");

        list = checkErrors(list, dic);

        for (String s : list) {
            System.out.println(s);
        }

        BST tree = new BST();
        tree.insert(65);
        tree.insert(54);
        tree.insert(85);
        tree.insert(19);
        tree.insert(60);
        tree.insert(80);
        tree.insert(89);
        tree.insert(8);
        tree.insert(35);
        tree.insert(70);
        tree.insert(83);
        tree.insert(67);
        tree.insert(75);

        ArrayList<Integer> arvore = halfTree(tree);
        
        System.out.println(arvore.toString());
    }

    //EX01
    public static LinkedList<String> checkErrors(LinkedList<String> str, Set<String> dictionary) {
        Map<String, String> duplicados = new HashMap<>();
        LinkedList<String> new_string = new LinkedList<>();
        String new_word;
        boolean check;
        int cont = 1;

        for (String word : str) {
            check = dictionary.contains(word);

            if (check == false) {
                if (duplicados.containsKey(word)) {
                    new_word = duplicados.get(word);
                } else {
                    new_word = "ERROR_" + cont;
                    duplicados.put(word, new_word);
                    cont++;
                }
            } else {
                new_word = word;
            }

            new_string.addLast(new_word);
        }

        return new_string;
    }

    //EX02
    public static Integer checkSequence(Graph<Integer, Character> trie, Character[] sequence) {
        Integer vert = 0;

        for (Character c : sequence) {
            Iterable<Edge<Integer, Character>> edges = trie.outgoingEdges(vert);
            for (Edge e : edges) {
                if (e.getElement().equals(c)) {
                    vert = (Integer) e.getVDest();
                    if (vert == null) {
                        return null;
                    }
                }
            }
        }
        if (vert < 100) {
            return vert;
        }
        return -1;
    }

    //EX04
    public static ArrayList<Integer> halfTree(BST tree) {
        int n = tree.height() / 2;
        Map<Integer, List<Integer>> level = tree.nodesByLevel();
        ArrayList<Integer> vec = new ArrayList<>();

        while (n >= 0) {
            for (Integer num : level.get(n)) {
                vec.add(num);
            }
            n--;
        }

        Collections.sort(vec);
        Collections.reverse(vec);

        return vec;
    }

    public static boolean checkHeap(ArrayList<Integer> heap) {
        for (int i = 1; i < heap.size(); i++) {
            if (heap.get((i + 1) / 2) > heap.get(i)) {
                return false;
            }
        }
        return true;
    }
}
