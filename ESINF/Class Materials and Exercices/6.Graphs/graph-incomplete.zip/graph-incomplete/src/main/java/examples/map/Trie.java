package examples.map;

import graph.*;

/**
 *
 * @author DEI-ESINF
 *
 */
public class Trie {

    public static Integer checkSequence(Graph<Integer, Character> trie, Character[] sequence) {

         throw new UnsupportedOperationException("Not supported yet.");
    }
}
