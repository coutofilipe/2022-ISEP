/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package esinf;

/**
 *
 */
public class RecursionExercices {
    
    /**
     *
     * @param m first parcel
     * @param n second parcel
     * @return the sum of the two parcels
     */
    public static int sum(int m, int n) {
        
        throw new UnsupportedOperationException("Not supported yet.");
    }
    
    /**
     *
     * @param d number in decimal base
     * @return the number converted to binary base
     */
    public static String decimalToBinary(Integer d) {
        
        throw new UnsupportedOperationException("Not supported yet.");         
    }
    
    /**
     *
     * @param d number to check
     * @return true if the number is a prime, false otherwise
     */
    public static boolean isPrime(int d) {
        
        return isPrime(d,2);
    }

    private static boolean isPrime(int d, int i) {
        
        throw new UnsupportedOperationException("Not supported yet.");
    }
    
    /**
     *
     * @param word word to check
     * @return true if the word is a palindrome, false otherwise
     */
    public static boolean isPalindrome(String word) {
        
        throw new UnsupportedOperationException("Not supported yet.");
    }
    
}
